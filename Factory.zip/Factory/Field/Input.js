class Input{
    constructor(){
        this.element = `<input type="text"/>`;
    }
}

export default Input;