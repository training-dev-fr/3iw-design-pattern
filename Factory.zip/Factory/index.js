import Input from "./Field/Input.js";

let form = document.querySelector(".form");

document.querySelector(".builder .input").addEventListener("click",function(){
    let input = new Input();
    form.innerHTML += input.element;
});