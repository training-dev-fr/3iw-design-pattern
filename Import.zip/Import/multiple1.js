export function addition(a,b){
    return a+b;
}

export function multiplication(a,b){
    return a*b;
}

// Pour l'importer dans un autre fichier :
// import {addition,multuplication} from './multiple1.js';