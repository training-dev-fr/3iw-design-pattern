function addition(a,b){
    return a+b;
}

export default addition;

// Pour l'importer dans un autre fichier :
// import addition from './default2.js';