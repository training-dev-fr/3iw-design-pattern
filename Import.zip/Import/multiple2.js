function addition(a,b){
    return a+b;
}

function multiplication(a,b){
    return a*b;
}

export {addition,multiplication};

// Pour l'importer dans un autre fichier :
// import {addition,multiplication} from './multiple2.js';