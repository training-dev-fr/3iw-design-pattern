function addition(a,b){
    return a+b;
}

function multiplication(a,b){
    return a*b;
}

export default {addition,multiplication};

// Pour l'importer dans un autre fichier :
// import calculator from './multiple-default.js';