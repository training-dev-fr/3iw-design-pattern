import calc from './lib.js';

console.log(calc.addition(3,5));