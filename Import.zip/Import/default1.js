export default function addition(a,b){
    return a+b;
}

// Pour l'importer dans un autre fichier :
// import addition from './default1.js';